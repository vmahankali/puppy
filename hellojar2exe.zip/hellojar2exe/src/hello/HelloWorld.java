package hello;
  
public class HelloWorld
{
    public static void main(String [] argv) // this is the entry point of program
    {
        System.out.println("Hello World!");
    }
}
